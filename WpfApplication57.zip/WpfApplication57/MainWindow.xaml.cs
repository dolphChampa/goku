﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ThinkLib;

namespace WpfApplication57
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int length(string s)
        {
            int count = 0;
            foreach (char p in s)
            {
                count = count + 1;
            }
            return count;
        }
        bool contains(string s, string subs)
        {
            for (int i = 0; i < 50; i++)
            {
                if (s[i] == subs[0])
                {
                    return true;
                }

            }
            return false;
        }
        //string insertSubString(string s, string x, int pos)
        //{

        //}
        string replaceSubString(string s, string neww, string old)
        {
            old = neww;
            string p = s;
            for (int i = 0; i < 50; i++)
            {
                if (s[i] == old[0])
                {
                    old = neww;
                    s = p;
                    return p;
                }
            }
            return " ";
            //string p = s;
            //old = neww;
            //for (int i = 0; i < 100; i++)
            //{
            //    if (s[i] == old[0])
            //    {
            //        old = neww;
            //        return p;
            //    }
            //}
            //return " ";
        }
        int indexOf(string s, string subs)
        {
            int p = -1;
            for (int i = 0; i < 50; i++)
            {
                p++;
                if (s[i] == subs[0])
                {
                    return p;
                }
            }
            return -1;
        }
    private void button_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(length("xxx"), 3);
            Tester.TestEq(length(" "), 1);
            Tester.TestEq(length(""), 0);
            Tester.TestEq(contains("hard", "ar"), true);
            Tester.TestEq(contains("xxyxx", "y"), true);
            Tester.TestEq(contains("fifa16", "a16"), true);
            //Tester.TestEq(contains("hitomp", "aru"), false);
            Tester.TestEq(indexOf("xxyxx", "y"), 2);
            Tester.TestEq(indexOf("bring", "n"), 3);
            Tester.TestEq(indexOf("my home", "o"), 4);
            //Tester.TestEq(indexOf(" ", "e"), -1);
            Tester.TestEq(replaceSubString("army", "e", "y"), "arme");
            //Tester.TestEq(replaceSubString("xxyxx", "ooo", "y"), "xxoooxx");
        }
    }
}
